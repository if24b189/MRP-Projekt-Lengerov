package org.example.server.util;

import org.example.server.http.Request;
import com.sun.net.httpserver.HttpExchange;

/**
 * Small helper that converts a low-level HttpExchange (from com.sun.net.httpserver)
 * into our internal Request DTO used inside the application framework.
 *
 * Responsibility:
 * - Extracts simple metadata like HTTP method and path.
 * - Later this mapper can be extended to parse headers, query parameters
 *   and body (JSON) into the Request object.
 */
public class RequestMapper {

    /**
     * Convert an HttpExchange into a Request object.
     * Currently only method and path are copied. This keeps the mapping
     * easy to understand while leaving room for extension.
     *
     * @param exchange incoming HTTP exchange from the JDK HttpServer
     * @return a populated Request object
     */
    public Request fromExchange(HttpExchange exchange) {
        Request request = new Request();
        request.setMethod(exchange.getRequestMethod());
        request.setPath(exchange.getRequestURI().getPath());

        return request;
    }
}