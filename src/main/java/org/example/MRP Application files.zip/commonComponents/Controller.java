package org.example.commonComponents;
import com.sun.net.httpserver.HttpHandler;

/**
 * Controller is a semantic alias for components that implement HTTP handling logic.
 *
 * In small projects we sometimes use the terms "Handler" and "Controller"
 * interchangeably. Here we keep Controller as a simple marker interface extending
 * the JDK's HttpHandler to clarify intent: a Controller contains business routing
 * logic for a particular resource (e.g., /users).
 *
 * The concrete controller classes in this project implement com.sun.net.httpserver.HttpHandler
 * directly (for simplicity) and can be placed into the Application's route map.
 */
public interface Controller extends HttpHandler {
    // intentionally empty - acts as a semantic alias for HttpHandler
}
