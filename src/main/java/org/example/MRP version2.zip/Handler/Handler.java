package org.example.Handler;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Placeholder HTTP handler used for demonstration.
 *
 * Note: The actual application registers resource-specific handlers (e.g. AuthHandler,
 * UserHandler) via the Application.getRoutes() map. This class exists so imports or
 * example wiring don't fail; it simply returns 501 Not Implemented.
 */
public class Handler implements HttpHandler {

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String body = "{\"error\":\"Not implemented (use specific handlers)\"}";
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(501, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }
}