package org.example.handler;

import org.example.models.Media;
import org.example.services.MediaService;
import org.example.server.http.*;

public class MediaHandler implements Handler {

    private final MediaService mediaService = new MediaService();

    @Override
    public void handle(Request req, Response res) {
        if (req.getMethod().equals("POST") && req.getPath().equals("/media")) {
            try {
                Media media = JsonUtil.fromJson(req.getBody(), Media.class);
                int userId = req.getUserId(); // aus Token
                mediaService.create(media, userId);
                res.setStatus(Status.CREATED);
            } catch (Exception e) {
                res.setStatus(Status.BAD_REQUEST);
            }
        }
    }
}
