package org.example.handler;

import org.example.services.FavoriteService;
import org.example.server.http.*;

public class FavoriteHandler implements Handler {

    private final FavoriteService service = new FavoriteService();

    @Override
    public void handle(Request req, Response res) {
        if (req.getMethod().equals("POST")) {
            try {
                int userId = req.getUserId();
                int mediaId = Integer.parseInt(req.getPathParam());
                service.add(userId, mediaId);
                res.setStatus(Status.OK);
            } catch (Exception e) {
                res.setStatus(Status.BAD_REQUEST);
            }
        }
    }
}