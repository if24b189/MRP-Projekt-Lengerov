package org.example.server;

import com.sun.net.httpserver.HttpServer;
import org.example.handler.*;
import org.example.server.http.*;

import java.net.InetSocketAddress;

public class Server {

    public void start() throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);

        Router router = new Router();

        router.register("/users", new UserHandler());
        router.register("/media", new MediaHandler());
        router.register("/ratings", new RatingHandler());
        router.register("/favorites", new FavoriteHandler());

        server.createContext("/", exchange -> {
            Request request = new Request(exchange);
            Response response = new Response(exchange);

            try {
                router.route(request, response);
            } catch (Exception e) {
                response.setStatus(Status.INTERNAL_SERVER_ERROR);
            }

            response.send();
        });

        server.start();
        System.out.println("Server started on http://localhost:8080");
    }
}
