package org.example.handler;

import org.example.models.Rating;
import org.example.services.RatingService;
import org.example.server.http.*;

public class RatingHandler implements Handler {

    private final RatingService ratingService = new RatingService();

    @Override
    public void handle(Request req, Response res) {
        if (req.getMethod().equals("POST") && req.getPath().equals("/ratings")) {
            try {
                Rating rating = JsonUtil.fromJson(req.getBody(), Rating.class);
                int userId = req.getUserId();
                ratingService.rate(rating, userId);
                res.setStatus(Status.CREATED);
            } catch (Exception e) {
                res.setStatus(Status.BAD_REQUEST);
            }
        }
    }
}
