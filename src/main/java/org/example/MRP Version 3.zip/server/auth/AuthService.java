package org.example.server.auth;

import java.util.HashMap;
import java.util.Map;

public class AuthService {

    private static final Map<String, Integer> tokens = new HashMap<>();

    public static String generateToken(int userId) {
        String token = userId + "-token";
        tokens.put(token, userId);
        return token;
    }

    public static Integer getUserId(String token) {
        return tokens.get(token);
    }
}
