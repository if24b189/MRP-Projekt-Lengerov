package org.example.services;

import databases.Database;
import models.User;

import java.sql.ResultSet;

public class UserService {

    public void register(User user) throws Exception {
        ResultSet rs = Database.findUser(user.getUsername());
        if (rs.next()) {
            throw new IllegalStateException("User exists");
        }
        Database.createUser(user.getUsername(), user.getPassword());
    }
}
