package org.example.server;

import org.example.handler.Handler;
import org.example.server.http.Request;
import org.example.server.http.Response;
import org.example.server.http.Status;

import java.util.HashMap;
import java.util.Map;

public class Router {

    private final Map<String, Handler> routes = new HashMap<>();

    public void register(String basePath, Handler handler) {
        routes.put(basePath, handler);
    }

    public void route(Request req, Response res) {
        for (String path : routes.keySet()) {
            if (req.getPath().startsWith(path)) {
                routes.get(path).handle(req, res);
                return;
            }
        }
        res.setStatus(Status.NOT_FOUND);
    }
}
