package org.example.handler;

import org.example.models.User;
import org.example.services.UserService;
import org.example.server.http.*;

public class UserHandler implements Handler {

    private final UserService userService = new UserService();

    @Override
    public void handle(Request req, Response res) {
        if (req.getMethod().equals("POST") && req.getPath().equals("/users/register")) {
            try {
                User user = JsonUtil.fromJson(req.getBody(), User.class);
                userService.register(user);
                res.setStatus(Status.CREATED);
            } catch (Exception e) {
                res.setStatus(Status.BAD_REQUEST);
            }
        }
    }
}
