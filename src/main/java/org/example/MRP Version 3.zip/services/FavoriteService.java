package org.example.services;

import databases.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class FavoriteService {

    public void add(int userId, int mediaId) throws Exception {
        String sql = "INSERT INTO favorites(user_id, media_id) VALUES (?,?)";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, mediaId);
            ps.executeUpdate();
        }
    }
}
