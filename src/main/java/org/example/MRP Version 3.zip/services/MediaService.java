package org.example.services;

import databases.Database;
import models.Media;

public class MediaService {

    public void create(Media media, int ownerId) throws Exception {
        Database.createMedia(
                media.getTitle(),
                media.getGenre(),
                media.getType(),
                media.getAgeRestriction(),
                ownerId
        );
    }
}