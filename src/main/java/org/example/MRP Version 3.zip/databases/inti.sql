CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
);

CREATE TABLE media (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    genre TEXT,
    type TEXT,
    age_restriction INT,
    owner_id INT REFERENCES users(id)
);

CREATE TABLE ratings (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id),
    media_id INT REFERENCES media(id),
    stars INT CHECK (stars BETWEEN 1 AND 5),
    comment TEXT,
    confirmed BOOLEAN DEFAULT FALSE
);

CREATE TABLE favorites (
    user_id INT REFERENCES users(id),
    media_id INT REFERENCES media(id),
    PRIMARY KEY (user_id, media_id)
);
