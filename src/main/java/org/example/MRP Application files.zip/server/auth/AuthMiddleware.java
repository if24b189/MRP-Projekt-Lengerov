package org.example.server.auth;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.Set;

/**
 * Middleware-like wrapper that enforces token-based authorization for wrapped handlers.
 *
 * Usage: new AuthMiddleware(authService, wrappedHandler)
 * - If the request path is under /auth (login/register) the request is passed through.
 * - Otherwise the Authorization header must contain a valid Bearer token.
 *
 * This is a small helper to avoid repeating token validation in every handler.
 */
public class AuthMiddleware implements HttpHandler {
    private final AuthService authService;
    private final HttpHandler next;

    // Paths that do not require authentication
    private static final Set<String> PUBLIC_PREFIXES = Set.of("/auth");

    public AuthMiddleware(AuthService authService, HttpHandler next) {
        this.authService = authService;
        this.next = next;
    }

    @Override
    public void  handle(HttpExchange exchange) throws IOException {
        String path = exchange.getRequestURI().getPath();
        // Allow public auth endpoints
        for (String p : PUBLIC_PREFIXES) {
            if (path.startsWith(p)) {
                next.handle(exchange);
                return;
            }
        }

        String authHeader = exchange.getRequestHeaders().getFirst("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            sendJson(exchange, 401, "{\"error\":\"Authorization header required\"}");
            return;
        }
        String token = authHeader.substring("Bearer ".length());
        try {
            if (authService.validateToken(token) == null) {
                sendJson(exchange, 401, "{\"error\":\"Invalid or expired token\"}");
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            sendJson(exchange, 500, "{\"error\":\"Database error\"}");
            return;
        }

        // token valid -> delegate
        next.handle(exchange);
    }

    private void sendJson(HttpExchange exchange, int status, String body) throws IOException {
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }
}

