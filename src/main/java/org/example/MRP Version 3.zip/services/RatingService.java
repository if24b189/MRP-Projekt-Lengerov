package org.example.services;

import databases.Database;
import models.Rating;

public class RatingService {

    public void rate(Rating rating, int userId) throws Exception {
        Database.upsertRating(
                userId,
                rating.getMediaId(),
                rating.getStars(),
                rating.getComment()
        );
    }
}