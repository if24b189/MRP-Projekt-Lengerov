package org.example.commonComponents;

import com.sun.net.httpserver.HttpHandler;
import org.example.server.UserHandler;
import org.example.server.UserService;
import org.example.server.auth.AuthHandler;
import org.example.server.auth.AuthService;
import org.example.server.auth.AuthMiddleware;

import java.util.HashMap;
import java.util.Map;

/**
 * Default-Implementierung der Application, erstellt Services + Handler und liefert die Routen-Map.
 *
 * Routing rules:
 * - The /auth context is public and handled by AuthHandler (login/register/logout/me).
 * - The /users context is protected by AuthMiddleware which validates tokens and then
 *   forwards requests to UserHandler.
 */
public class DefaultApplication implements Application {

    @Override
    public Map<String, HttpHandler> getRoutes() {
        // business services
        UserService userService = new UserService();
        AuthService authService = new AuthService(userService);

        // handlers (HttpHandler implementations)
        AuthHandler authHandler = new AuthHandler(authService);
        UserHandler userHandler = new UserHandler(userService);

        // Wrap userHandler with AuthMiddleware to enforce token checks for non-auth routes
        AuthMiddleware authMiddlewareForUsers = new AuthMiddleware(authService, userHandler);

        // routing map
        Map<String, HttpHandler> routes = new HashMap<>();
        // /auth is public (login/register)
        routes.put("/auth", authHandler);
        // /users is protected by middleware
        routes.put("/users", authMiddlewareForUsers);

        return routes;
    }
}
