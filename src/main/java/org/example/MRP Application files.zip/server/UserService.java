package org.example.server;

import java.security.SecureRandom;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;

import org.example.databases.Database;
import org.example.models.User;

import java.sql.SQLException;
import java.util.UUID;

/**
 * Business service responsible for user-related operations.
 *
 * Responsibilities:
 * - Register a new user (validation + persistence)
 * - Authenticate (login) and issue tokens
 * - Resolve users by id or token
 * - Update and delete users
 *
 * Notes:
 * - Password hashing is NOT implemented in this demo. In a production app you must
 *   never store plaintext passwords. Use bcrypt/argon2 and a secure verifier.
 * - Token generation uses a secure random 256-bit value encoded in URL-safe Base64.
 */
public class UserService {

    private static final SecureRandom secureRandom = new SecureRandom();


    /**
     * Registers a new user after validating inputs and checking uniqueness.
     *
     * @param username desired username (must be unique and at least 3 chars)
     * @param password desired password (non-empty)
     * @return created User object read back from database
     * @throws IllegalArgumentException on validation failure
     * @throws SQLException on database errors
     */
    public User registerUser(String username, String password) throws IllegalArgumentException, SQLException {
        // Validation
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username cannot be empty");
        }
        if (password == null || password.trim().isEmpty()) {
            throw new IllegalArgumentException("Password cannot be empty");
        }
        if (username.length() < 3) {
            throw new IllegalArgumentException("Username must be at least 3 characters long");
        }

        // Check if user already exists
        User existingUser = Database.findUserByUsername(username);
        if (existingUser != null) {
            throw new IllegalArgumentException("Username already exists");
        }

        // Create user
        Database.insertUser(username, password);
        return Database.findUserByUsername(username);
    }


    /**
     * Authenticates a user and returns a token when successful.
     *
     * Steps:
     * - Look up the user by username
     * - Compare supplied password (plain-text) with stored password (plain-text)
     * - Generate a secure token and persist it with expiry
     *
     * @param username provided username
     * @param password provided password
     * @return token string usable in Authorization: Bearer <token>
     * @throws IllegalArgumentException if user not found or password invalid
     * @throws SQLException on DB errors
     */
    public String loginUser(String username, String password) throws IllegalArgumentException, SQLException {
        if (username == null || password == null) {
            throw new IllegalArgumentException("Username and password cannot be null");
        }

        User user = Database.findUserByUsername(username);
        if (user == null) {
            throw new IllegalArgumentException("User not found");
        }

        // not hashed - placeholder only
        if (!user.getPassword().equals(password)) {
            throw new IllegalArgumentException("Invalid password");
        }

        // Generate token
        String token = generateSecureToken();
        Database.storeToken(user.getId(), token, Instant.now().plus(30, ChronoUnit.DAYS));


        //String token = username + "-mrpToken-" + UUID.randomUUID().toString().substring(0, 8);
        //Database.storeToken(user.getId(), token);

        return token;
    }

    /**
     * Generates a cryptographically secure random token (URL-safe base64).
     * @return token string
     */
    public static String generateSecureToken() {
        byte[] bytes = new byte[32]; // 256-bit
        secureRandom.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    /**
     * Fetch user by id.
     */
    public User getUserById(int userId) throws SQLException {
        return Database.findUserById(userId);
    }

    /**
     * Resolve a user from a previously issued token.
     * Returns null if token invalid/expired.
     */
    public User getUserByToken(String token) throws SQLException {
        Integer userId = Database.validateToken(token);
        if (userId != null) {
            return Database.findUserById(userId);
        }
        return null;
    }

    /**
     * Update username and/or password for a user.
     * If a field is null or blank the existing value is kept.
     */
    public void updateUser(int userId, String newUsername, String newPassword) throws IllegalArgumentException, SQLException {
        User user = Database.findUserById(userId);
        if (user == null) {
            throw new IllegalArgumentException("User not found");
        }

        // Validate new username if provided
        if (newUsername != null && !newUsername.trim().isEmpty()) {
            if (newUsername.length() < 3) {
                throw new IllegalArgumentException("Username must be at least 3 characters long");
            }
            User userWithSameUsername = Database.findUserByUsername(newUsername);
            if (userWithSameUsername != null && userWithSameUsername.getId() != userId) {
                throw new IllegalArgumentException("Username already exists");
            }
        } else {
            // Keep existing username if not provided
            newUsername = user.getUsername();
        }

        // Keep existing password if not provided
        if (newPassword == null || newPassword.trim().isEmpty()) {
            User existingUser = Database.findUserByUsername(user.getUsername());
            newPassword = existingUser.getPassword();
        }

        Database.updateUser(userId, newUsername, newPassword);
    }

    /**
     * Delete a user by id. Throws if user does not exist.
     */
    public void deleteUser(int userId) throws SQLException {
        User user = Database.findUserById(userId);

        if (user == null) {
            throw new IllegalArgumentException("User not found");
        }

        Database.deleteUser(userId);
    }
}