package org.example.commonComponents;

import com.sun.net.httpserver.HttpHandler;

import java.util.Map;

/**
 * Application abstraction for this small framework.
 *
 * For the current project we only need the ability to supply routing (path -> HttpHandler).
 * The older handle(Request) method was not used by DefaultApplication and caused
 * compile issues due to unused internal DTOs. Keep the interface minimal and focused.
 */
public interface Application {
    // Provide a map of URL paths (contexts) to HttpHandler implementations.
    Map<String, HttpHandler> getRoutes();
}