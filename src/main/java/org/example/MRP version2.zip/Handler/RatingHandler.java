package org.example.Handler;

public class RatingHandler {
}
