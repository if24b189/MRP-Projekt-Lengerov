package org.example.databases;

import java.sql.*;

public class Database {

    private static final String URL = "jdbc:postgresql://localhost:5432/mrp";
    private static final String USER = "mrp";
    private static final String PASSWORD = "mrp";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // ---------- USERS ----------
    public static void createUser(String username, String passwordHash) throws SQLException {
        String sql = "INSERT INTO users(username, password) VALUES (?,?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, passwordHash);
            ps.executeUpdate();
        }
    }

    public static ResultSet findUser(String username) throws SQLException {
        String sql = "SELECT * FROM users WHERE username=?";
        PreparedStatement ps = getConnection().prepareStatement(sql);
        ps.setString(1, username);
        return ps.executeQuery();
    }

    // ---------- MEDIA ----------
    public static void createMedia(String title, String genre, String type, int age, int ownerId) throws SQLException {
        String sql = "INSERT INTO media(title, genre, type, age_restriction, owner_id) VALUES (?,?,?,?,?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setString(1, title);
            ps.setString(2, genre);
            ps.setString(3, type);
            ps.setInt(4, age);
            ps.setInt(5, ownerId);
            ps.executeUpdate();
        }
    }

    public static ResultSet getAllMedia() throws SQLException {
        String sql = "SELECT * FROM media";
        PreparedStatement ps = getConnection().prepareStatement(sql);
        return ps.executeQuery();
    }

    // ---------- RATINGS ----------
    public static void upsertRating(int userId, int mediaId, int stars, String comment) throws SQLException {
        String check = "SELECT id FROM ratings WHERE user_id=? AND media_id=?";
        try (PreparedStatement ps = getConnection().prepareStatement(check)) {
            ps.setInt(1, userId);
            ps.setInt(2, mediaId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String update = "UPDATE ratings SET stars=?, comment=? WHERE id=?";
                try (PreparedStatement ups = getConnection().prepareStatement(update)) {
                    ups.setInt(1, stars);
                    ups.setString(2, comment);
                    ups.setInt(3, rs.getInt("id"));
                    ups.executeUpdate();
                }
            } else {
                String insert = "INSERT INTO ratings(user_id, media_id, stars, comment, confirmed) VALUES (?,?,?,?,false)";
                try (PreparedStatement ins = getConnection().prepareStatement(insert)) {
                    ins.setInt(1, userId);
                    ins.setInt(2, mediaId);
                    ins.setInt(3, stars);
                    ins.setString(4, comment);
                    ins.executeUpdate();
                }
            }
        }
    }
}
